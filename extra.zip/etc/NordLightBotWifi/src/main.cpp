#include <Arduino.h>

#define DEBUG false

#include <AsyncStream.h>
AsyncStream<255> serial(&Serial, ';');

#include <CTBot.h>
CTBot TelegramBot;

String ssid = "Astra"; // Имя Сети
String pass = "NotAnyAstra";       // Пароль Сети

String token = "1371360165:AAEVjHpAzaJrTvF5bxdx77ppk88gLsoNkLI"; // Телеграм токен для бота
int myid = 665408649; // Индификатор Хозяина

void setup()
{
  Serial.begin(115200);
  Serial.setTimeout(5);
  pinMode(16, OUTPUT);

  digitalWrite(16, HIGH); 
  TelegramBot.wifiConnect(ssid, pass);
  digitalWrite(16, LOW);

  if (DEBUG)
    Serial.println("WifiConnection OK");

  TelegramBot.setTelegramToken(token);
  
  if (DEBUG)
  {
    if (TelegramBot.testConnection())
      Serial.println("Bot OK");
    else
      Serial.println("Bot Bad");
  }
}

void loop()
{
  TBMessage msg;
  if (CTBotMessageText == TelegramBot.getNewMessage(msg))
  {
    digitalWrite(16, HIGH); 
    if (msg.text.equalsIgnoreCase("/move"))
    {                                                    // Отправка команды на движение
      Serial.print("1;");                              
      TelegramBot.sendMessage(msg.sender.id, "Bot is now ON"); // Ответ отправителю
    }
    else if (msg.text.equalsIgnoreCase("/stop"))
    {                                                     // Отправка команды на остановку
      Serial.print("0;");                                 
      TelegramBot.sendMessage(msg.sender.id, "Bot is now OFF"); // Ответ отправителю
    }
    else
    { 
      // Справочное сообщение
      String reply = (String) "Welcome " + msg.sender.username + (String) ". Try /move or /stop";
      TelegramBot.sendMessage(msg.sender.id, reply); 
    }
    digitalWrite(16, LOW); 
  }
  // Обработка откладочных сообщений с Ардуино
  if (serial.available())
  {
    digitalWrite(16, HIGH); 
    if (DEBUG)
      Serial.println(serial.buf);
    TelegramBot.sendMessage(myid, serial.buf);
    digitalWrite(16, LOW); 
  }
}