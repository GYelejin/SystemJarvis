#include <Arduino.h>

#define DEBUG true

//-----------------Sensors-------------------------//
#include <NewPing.h>

#define MAX_DISTANCE 100 // Maximum distance we want to ping for (in centimeters). Maximum sensor distance is rated at 400-500cm.

#define TRIGGER_PINL 8 // Left Sensor Pins
#define ECHO_PINL 9    

#define TRIGGER_PINF 11 // Front Sensor Pins
#define ECHO_PINF 10    

#define TRIGGER_PINR 12  // Right Sensor Pins
#define ECHO_PINR 13    

NewPing sonarLeft(TRIGGER_PINL, ECHO_PINL, MAX_DISTANCE); // NewPing setup of pins and maximum distance.
NewPing sonarRight(TRIGGER_PINR, ECHO_PINR, MAX_DISTANCE);
NewPing sonarFront(TRIGGER_PINF, ECHO_PINF, MAX_DISTANCE);

#define LEFT_LINEPIN 2 // Left Line Sendor pin
#define RIGHT_LINEPIN 3 // Right Line Sensor pin

boolean leftline, rightline;

boolean frontwall, leftwall, rightwall;

float oldLeftSensor, oldRightSensor, leftSensor, rightSensor, frontSensor, oldFrontSensor, lSensor, rSensor, fSensor;

const int wall_threshold = 50;
const int front_threshold = 13;
//-----------------End 0f Sensors-------------------------//

//-------------------------Motor---------------------//
#include <GyverMotor.h>

#define DIR_LEFT 7
#define SPEED_LEFT 6
#define DIR_RIGHT 4
#define SPEED_RIGHT 5

#define SPEED 100
GMotor leftmotor(DRIVER2WIRE, DIR_LEFT, SPEED_LEFT, LOW);
GMotor rightmotor(DRIVER2WIRE, DIR_RIGHT, SPEED_RIGHT, LOW);

int RMS;
int LMS;
//--------------------------End of Motor--------------//

//-------------------------Motor---------------------//
#include "Wire.h"
#include <LiquidCrystal_I2C.h> 

LiquidCrystal_I2C lcd(0x27,16,2); 

//--------------------------End of Motor--------------//


#include <AsyncStream.h>
AsyncStream<2> serial(&Serial, ';');

#include <TimerMs.h>
TimerMs tmr(1000, true);
TimerMs pidtmr(10, true);
TimerMs tmr_delay_for_pid(150, false, 1);
TimerMs tmrfordisplay(500, true);

//-------------------------PID value----------------------//
const float kP = 0.7;
const float kI = 0.4;
const float kD = 0.5;
const int offset = 30;
float oldErrorP, totalError;
float errorP, errorI, errorD;
long delay_for_pid = 0;
//-------------------------End of PID value---------------//

int active_state = 0; // Переменная отвечает за активный режим

//------------------------Debug---------------------//
String dataToStr() // Упаковывает  данные для отправки по UART
{
  return "\n" + String(leftSensor) + "," + String(rightSensor) + "," + String(frontSensor) + "," + String(errorP) + "," + String(errorI) + "," + String(errorD) + "," + String(totalError) + "," + String(LMS) + "," + String(RMS) + ";";
}

//-------------------------Motor---------------------//
void SetSpeed(int leftWheelSpeed, int rightWheelSpeed) // Установка скорости на оба мотора
{
  leftmotor.setSpeed(leftWheelSpeed);
  rightmotor.setSpeed(rightWheelSpeed);
}
//--------------------------End of Motor--------------//

//------------------------PID------------------------//
void PID() // Корректировка траектории на основе ПИД регулятора
{
  errorP = leftSensor - offset;
  errorI = 0.6 * errorI + errorP;
  errorD = errorP - oldErrorP;

  totalError = kP * errorP + kI * errorI + kD * errorD;

  oldErrorP = errorP;

  RMS = SPEED + totalError;
  LMS = SPEED - totalError;

  if (DEBUG == true)
  {
    if (tmr.tick())
      Serial.print(dataToStr());
  }
  SetSpeed(LMS, RMS);
}

//--------------------------Sensors-------------------//
void readSensors() // Получения и обработка данных в коде
{
  leftline = digitalRead(LEFT_LINEPIN);
  rightline = digitalRead(RIGHT_LINEPIN);

  lSensor = sonarLeft.ping_cm(); // ping in cm
  rSensor = sonarRight.ping_cm();
  fSensor = sonarFront.ping_cm();

  if (lSensor == 0)
  {
    lSensor = oldLeftSensor;
  }
  if (rSensor == 0)
  {
    rSensor = oldRightSensor;
  }
  if (fSensor == 0)
  {
    fSensor = oldFrontSensor;
  }
  
  leftSensor = (lSensor + oldLeftSensor) / 2; // average distance between old & new readings to make the change smoother
  rightSensor = (rSensor + oldRightSensor) / 2;
  frontSensor = (fSensor + oldFrontSensor) / 2;

  oldLeftSensor = leftSensor; // save old readings for movment
  oldRightSensor = rightSensor;
  oldFrontSensor = frontSensor;
}

void walls() // Обработка сенсоров
{
  leftwall = leftSensor < wall_threshold;
  rightwall = rightSensor < wall_threshold;
  frontwall = frontSensor < front_threshold;
}
//---------------------------End of Sensors-----------------//
//--------------------------Callback----------------------//
// Функции обратного вызова
void pidstartpmd() // Ожидание поворота и его проверка
{ 
  if (leftwall && frontwall && !rightwall) pidtmr.resume();
  else tmr_delay_for_pid.resume();
}

void printinfo() // Откладка данных и корректировки траектории
{
  lcd.clear();
  lcd.setCursor(0,0);              
  lcd.print(String(leftSensor) + "," + String(rightSensor) + "," + String(frontSensor));
  lcd.setCursor(0,1);
  lcd.print(String(totalError) + "," + String(LMS) + "," + String(RMS));
  }

void printwait() // Печать сообщения об ожидании
{ 
  lcd.clear();
  lcd.print("Waiting for");
  lcd.setCursor(0, 1);
  lcd.print("for command");
  for (int i = 0; i < 3; i++)
  {
    lcd.print(".");
  }
}

void callback_for_lcd(){ // Выбор сообщений для вывода на экран
  if (!active_state) printwait();
  else printinfo();
}

void setup() // Инициализациия
{
  // Запуск слушателя UART
  Serial.begin(115200);
  Serial.setTimeout(5);

  // Присвоение функций обратного вызова
  tmrfordisplay.attach(callback_for_lcd);
  pidtmr.attach(PID);
  tmr_delay_for_pid.attach(pidstartpmd);

  

  lcd.init();                     
  lcd.backlight();
  lcd.noBlink();               
  lcd.setCursor(0,0);             
  lcd.print("initialisation...");
  
  leftmotor.setMode(AUTO);
  rightmotor.setMode(AUTO);

  tmrfordisplay.tick();
}

void loop()
{
  // Часть цикла для обработки данных с UART
  if (serial.available())
  {
    String cmd = serial.buf;
    if (cmd.toInt() == 0)
    {
      active_state = false;
      printwait();
    }
    else if (cmd.toInt() == 1)
    {
      active_state = true;
    }
  }
  // Активная часть отвечает за передвижения
  if (active_state == 1)
  {
    // Вызовы функций обратного вызова
    tmrfordisplay.tick(); 
    pidtmr.tick();
    tmr_delay_for_pid.tick();
    // Опрос Датчиков
    readSensors(); 
    walls();

    if (leftline || rightline) // Остановка при достижении чекпоинта
    {
      active_state = 0;
    }

    if ((leftwall && frontwall && !rightwall) && !tmr_delay_for_pid.active()) // Объезд препятствия впереди
    {
      SetSpeed(160, 1);
      pidtmr.stop();
      tmr_delay_for_pid.resume();
    } 
  }
  else // Остановка
  {
    SetSpeed(1, 1);
  }
}
